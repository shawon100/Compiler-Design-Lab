
im=imread('football.jpg');
imshow(im);


