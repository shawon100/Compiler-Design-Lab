#include <bits/stdc++.h>
using namespace std;

long long int i,j,k,l,n,m=0,t,tc;
string s[100],st,str="";
char nt,ft,cc;
vector<string>ss;
vector<int>sm;
vector<char>sy;


long long int firstfollow(int v,char ch)
{
    int fm=0;
    tc=0;
    while(v<=n)
    {
         st=s[v];
         cc=ch;
         m=2;

         if(st[0]==ch)
         {

             //cout<<"Get"<<st[0]<<v<<endl;
             ft=st[0];
         for(j=0;j<st.length();j++)
         {
             if(st[j]=='=')
             {
                 l=j;
                 break;
             }

         }
         for(j=l+1;j<st.length();j++)
         {
              str="";
              if((st[j]=='+' || st[j]=='*' ||st[j]=='/' ||st[j]=='-' || st[j]=='(') || (st[j]>='a' && st[j]<='z'))
              {
                  m=1;
                  str=str+st[j];
                  //cout<<str<<endl;
                  //cout<<st[j]<<endl;
                  break;
              }
              else
              {
                  m=0;
                  nt=st[j];
                  //cout<<"Nt"<<nt<<endl;
                  break;

              }
         }
         if(m==1)
         {

            ss.push_back(str);
            break;
         }
         else if(m==0)
         {
               i=i+1;
               if(i>n)
               {
                   break;
               }
               firstfollow(i,nt);
         }
     }
     else
     {
         i=i+1;
         if(i>n)
         {
            break;
         }
         firstfollow(i,nt);
     }

     v++;
}

}



int main()
{
    long long int fl=0;
     cin>>n;
     for(i=1;i<=n;i++)
     {
         cin>>s[i];
     }

      i=1;
      st=s[1];
      nt=st[0];
      //cout<<nt<<endl;
      for(t=1;t<=n;t++)
      {
                st=s[t];
                nt=st[0];
                 ft=st[0];
                 for(k=0;k<sy.size();k++)
                 {
                     if(ft==sy[k])
                     {
                            fl=1;
                             break;
                     }
                 }
                 if(fl==0)
                 {
                     sy.push_back(ft);
                     firstfollow(t,nt);
                 }


      }
      cout<<endl;
      cout<<"First and Follow"<<endl<<endl;
      for(i=1;i<=ss.size();i++)
      {
          if(ss[i-1]==ss[i])
          {
              swap(ss[i],ss[i+1]);
          }
          cout<<sy[i-1]<<"=";
          cout<<ss[i-1]<<endl;
      }

      return 0;


}

